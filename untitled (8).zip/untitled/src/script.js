<script>
  const form = document.getElementById("subscribe-form");
  const input = document.getElementById("email-input");
  const msg = document.getElementById("message");

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    const email = input.value.trim();
    const valid = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email);

    if (valid) {
      msg.style.color = "lightgreen";
      msg.textContent = "Thanks for subscribing!";
      input.value = "";
    } else {
      msg.style.color = "red";
      msg.textContent = "Please enter a valid email.";
    }
  });
</script>
<script>
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
        }
      });
    },
    { threshold: 0.1 }
  );

  document.querySelectorAll(".fade-in").forEach(el => observer.observe(el));
</script>
<section class="fade-in">
  <!-- Your content -->
</section>
<script>
  const hamburger = document.getElementById("hamburger");
  const navLinks = document.getElementById("navLinks");

  hamburger.addEventListener("click", () => {
    navLinks.classList.toggle("show");
  });
</script>
<script>
  const themeBtn = document.getElementById("themeToggle");

  themeBtn.addEventListener("click", () => {
    document.body.classList.toggle("light-mode");
    themeBtn.textContent = document.body.classList.contains("light-mode") ? "🌞" : "🌙";
  });
</script>
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const authRoutes = require('./routes/auth');

dotenv.config();
const app = express();

app.use(cors());
app.use(express.json());
app.use('/api/auth', authRoutes);

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true, useUnifiedTopology: true,
}).then(() => {
  console.log('MongoDB connected');
  app.listen(process.env.PORT, () =>
    console.log(`Server running on http://localhost:${process.env.PORT}`)
  );
}).catch(err => console.error(err));
const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, required: true, unique: true },
  password: String,
  goals: {
    dailyMinutes: { type: Number, default: 60 },
    reminderInterval: { type: Number, default: 60 }
  },
  movements: [
    {
      time: String,
      activity: String,
      minutes: Number
    }
  ],
  badges: [String]
});

module.exports = mongoose.model('User', userSchema);
const express = require('express');
const { signup, login } = require('../controllers/authController');
const router = express.Router();

router.post('/signup', signup);
router.post('/login', login);

module.exports = router;
const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.signup = async (req, res) => {
  const { name, email, password } = req.body;
  try {
    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ msg: 'Email already in use' });

    const hash = await bcrypt.hash(password, 10);
    const user = await User.create({ name, email, password: hash });
    res.status(201).json({ msg: 'User created', userId: user._id });
  } catch (err) {
    res.status(500).json({ msg: 'Error signing up' });
  }
};

exports.login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ msg: 'Invalid email or password' });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ msg: 'Invalid email or password' });

    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '2d' });
    res.json({ token, user: { name: user.name, email: user.email } });
  } catch (err) {
    res.status(500).json({ msg: 'Login failed' });
  }
};
